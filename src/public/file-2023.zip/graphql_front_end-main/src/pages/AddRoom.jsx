import { useState } from "react";
import { gql, useMutation } from "@apollo/client";
import { useNavigate } from "react-router-dom";

const ADD_ROOM = gql`
  mutation Mutation($input: CreateRoomInput!) {
    createRoom(input: $input) {
      id
      room_name
      for_stuff
      floor
    }
  }
`;

function CreateRoom() {
  const [room_name, setName] = useState("");
  const [floor, setFloor] = useState(1);
  const [for_stuff, setForStuff] = useState(false);
  const [addRoom, { loading, error }] = useMutation(ADD_ROOM);
  const navigate = useNavigate();

  const disabled = !room_name || !floor;

  if (loading) {
    return "Loading...";
  }

  if (error) {
    return `Error: ${error.message}`;
  }

  return (
    <div className="bg-warning w-100 vh-100 pt-4">
      <h2 className="text-center m-4">Add New Room</h2>

      <div className="d-flex justify-content-center ">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            addRoom({
              variables: { input: { room_name, floor, for_stuff } },
            }).then(({ data }) => {
              navigate(`/${data.createRoom.id}`);
            });
          }}
          className="w-75 h-75 bg-light d-flex flex-column justify-content-center p-5"
        >
          <div>
            <label className="form-label">Name: </label>
            <input
              className="form-control"
              name="room_name"
              type="text"
              //   value={update.room_name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div>
            <label className="form-label">Floor: </label>
            <input
              className="form-control"
              name="floor"
              type="number"
              //   value={update.floor}
              onChange={() => setFloor(floor)}
            />
          </div>
          <div>
            <label>For Stuff: </label>
            <select
              className="form-control"
              name="for_stuff"
              id="id"
              onSelect={(e) => setForStuff(e.target.value)}
            >
              <option value="true">Hodimlar uchun</option>
              <option value="false">O`quv xonasi</option>
            </select>
          </div>
          <button
            className="btn btn-success w-100"
            type="submit"
            disabled={disabled}
          >
            Save
          </button>
        </form>
      </div>
    </div>
  );
}

export default CreateRoom;
