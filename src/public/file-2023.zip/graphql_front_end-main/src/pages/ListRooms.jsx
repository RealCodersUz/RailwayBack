import { gql, useQuery } from "@apollo/client";

const GET_ROOMS = gql`
  query Query {
    rooms {
      list {
        id
        room_name
        floor
        for_stuff
      }
    }
  }
`;

function ListRooms() {
  const { loading, error, data } = useQuery(GET_ROOMS);

  if (loading) return "Loading...";
  if (error) return `Error: ${error.message}`;

  console.log(data);
  return (
    <div className="bg-warning w-100 vh-100">
      <div className="d-flex justify-content-between">
        <h1 className="text-center mb-4">Rooms App</h1>
        <a className="btn btn-success" href="/add">
          Add New
        </a>
      </div>
      {data.rooms.list.map((room) => (
        <div key={room.id} className="d-flex justify-content-center">
          <span className="d-flex p-4 bg-light w-75 justify-content-between">
            <h3>
              {room.room_name}, {room.floor}-qavatda
              {room.for_stuff ? ", Hodimlar uchun" : ""}
            </h3>
            <article className="d-flex justify-content-between gap-2">
              <a href={`/${room.id}`}>
                <i className="fa-regular fa-eye warning fs-4"></i>
              </a>
              <a href={`/edit/${room.id}`}>
                <i className="fa-regular fa-pen-to-square fs-4"></i>
              </a>
              <a href={`/remove/${room.id}`}>
                <i className="fa-solid fa-trash danger fs-4"></i>
              </a>
            </article>
          </span>
          {/* <h4>{room.for_stuff ? "Hodimlar uchun" : ""}</h4> */}
          {/* <span>{room.floor}-qavatda</span> */}
        </div>
      ))}
      {/* {data.rooms.list.map((room) => (
        <li key={room.id}>
          <p>
            {room.room_name} - by {room.floor}
          </p>
        </li>
      ))} */}
    </div>
  );
}

export default ListRooms;
