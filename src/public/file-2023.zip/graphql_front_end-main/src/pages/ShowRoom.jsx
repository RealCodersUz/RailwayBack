import { useParams } from "react-router-dom";
import { gql, useQuery } from "@apollo/client";

const GET_ROOM = gql`
  query Query($id: ID!) {
    room(id: $id) {
      id
      room_name
      floor
      for_stuff
    }
  }
`;

function RoomShow() {
  const { id } = useParams();
  const { loading, error, data } = useQuery(GET_ROOM, {
    variables: { id },
  });

  if (loading) {
    return "Loading...";
  }

  if (error) {
    console.log(error);
    return `Error: ${error.message}`;
  }

  return (
    <div className="bg-warning w-100 vh-100">
      <h1 className="text-center"> Room Details</h1>
      {/* <p> {data.room.id}</p> */}
      <div className="d-flex flex-row justify-content-center gap-5 h-75 flex-md-wrap">
        <article className="w-25 w-sm-100 bg-light p-4 h-50 border border-dark">
          <p>Name: {data.room.room_name}</p>
        </article>
        <article className="">
          <p className="w-100 bg-light p-2 border border-dark">
            Floor: {data.room.floor} - qavatda
          </p>
          <p className="w-100 bg-light p-2 border border-dark">
            Specialty: {data.room.for_stuff ? "Hodimlar uchun" : "O'quv Xonasi"}
          </p>
        </article>
      </div>
    </div>
  );
}

export default RoomShow;
