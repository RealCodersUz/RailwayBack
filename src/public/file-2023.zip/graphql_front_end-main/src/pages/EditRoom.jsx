import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { gql, useQuery, useMutation } from "@apollo/client";

const GET_ROOMS = gql`
  query GetRoom($id: ID!) {
    room(id: $id) {
      id
      room_name
      floor
      for_stuff
    }
  }
`;

const UPDATE_ROOMS = gql`
  mutation Mutation($updateRoomId: ID!, $input: UpdateRoomInput!) {
    updateRoom(id: $updateRoomId, input: $input) {
      id
      room_name
      for_stuff
      floor
    }
  }
`;
// eslint-disable-next-line react-refresh/only-export-components
function RoomUpdate() {
  const { id } = useParams();
  console.log(id);
  const navigate = useNavigate();
  const [update, setUpdate] = useState({
    room_name: "",
    floor: 0,
    for_stuff: false,
  });
  const { loading, error, data } = useQuery(GET_ROOMS, {
    variables: { id },
  });
  const [updateRoom, { loading: loading1, error: error1 }] =
    useMutation(UPDATE_ROOMS);

  useEffect(() => {
    if (data && data.room) {
      setUpdate(data.room);
    }
  }, [data]);

  if (loading || loading1) {
    return "Loading...";
  }

  if (error || error1) {
    return `Error: ${error ? error.message : error1.message}`;
  }

  return (
    <div className="bg-warning w-100 vh-100 pt-4">
      <h2 className="text-center m-4">Update Room</h2>

      <div className="d-flex justify-content-center ">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const { id, __typename, ...updateInput } = update;
            console.log(__typename);
            updateRoom({
              variables: { updateRoomId: id, input: updateInput },
            }).then(({ data }) => {
              navigate(`/${data.updateRoom.id}`);
            });
          }}
          className="w-75 h-75 bg-light d-flex flex-column justify-content-center p-5"
        >
          <div>
            <label className="form-label">Name: </label>
            <input
              className="form-control"
              name="room_name"
              type="text"
              value={update.room_name}
              onChange={(e) =>
                setUpdate({ ...update, room_name: e.target.value })
              }
            />
          </div>
          <div>
            <label className="form-label">Floor: </label>
            <input
              className="form-control"
              name="floor"
              type="number"
              value={update.floor}
              onChange={(e) => setUpdate({ ...update, floor: +e.target.value })}
            />
          </div>
          <div>
            <label>For Stuff: </label>
            <select
              className="form-control"
              name="for_stuff"
              id="id"
              onSelect={(e) =>
                setUpdate({ ...update, for_stuff: e.target.value })
              }
            >
              <option value="true">Hodimlar uchun</option>
              <option value="false">O`quv xonasi</option>
            </select>
          </div>
          <button className="btn btn-success w-100" type="submit">
            Save
          </button>
        </form>
      </div>
    </div>
  );
}

export default await RoomUpdate;
