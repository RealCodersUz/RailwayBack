import { Route, Routes } from "react-router-dom";
import ShowRoom from "./pages/ShowRoom";
import EditRoom from "./pages/EditRoom";
import ListRooms from "./pages/ListRooms";
import RemoveRoom from "./pages/RemoveRoom";
import CreateRoom from "./pages/AddRoom";

function App() {
  return (
    <>
      {/* <ListRooms /> */}
      <Routes>
        <Route path="/" element={<ListRooms />} />
        <Route path="/:id" element={<ShowRoom />} />
        <Route path="/add" element={<CreateRoom />} />
        <Route path="/edit/:id" element={<EditRoom />} />
        <Route path="/remove/:id" element={<RemoveRoom />} />
      </Routes>
    </>
  );
}

export default App;

// import ShowRooms from "./pages/ShowRoom";
// // import ListRooms from './pages/ListBooks';

// function App() {
//   return (
//     <>
//       {/* <Listooks /> */}
{
  /* //       <ShowRooms />
//     </>
//   );
// } */
}

// export default App;
